<!DOCTYPE html>

<html>

<head>

<meta charset = "utf-8">

<title>Search Results</title>

<style type = "text/css">

table

{

background-color: lightyellow;

border-collapse: collapse;

border: 1px solid gray;

}

th, td

{

padding: 5px;

border: 1px solid gray;

}

tr:nth-child(even)

{

background-color: white;

}

tr: first-child

{

background-color: lightblue;

}

</style>

</head>

<body>

<?php

$query = "SELECT * FROM myurltable";

if( !( $mydb = mysql_connect( "localhost", "iw3htp", "password" ) ) )

die( "<p>Couldn't connect to the mydb</P>");

if ( !mysql_select_db( "MYURLs", $mydb ) )

die( "<p>Couldn't open URL DB</p></body></html>" );

if ( !( $resultant = mysql_query( $query, $mydb ) ) )

{

print( "<p>Couldn't execute the query</P>" );

die( mysql_error() );

}

?>

<h1>MYURL UrlDescriptions</h1>

<table>

<caption>UrlDescriptions stored in the mydb</caption>

<tr>

<th>MYURL</th>

<th>UrlDescription</th>

</tr>

<?php

for ( $count = 0; $rows = mysql_fetch_row( $resultant ); ++$count )

{

foreach ( $rows as $keys => $values )

print( "<td>$values</td>" );

print( "</tr>" );

}

mysql_close( $mydb );

?>

</table>

</body>

</html>