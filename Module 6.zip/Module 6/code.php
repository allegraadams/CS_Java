<!DOCTYPE html>

<html>

<head>

<meta charset = "utf-8">

<title>Search Results</title>

<style type = "text/css">

body

{

font-family: Monospace;

background-color: lightblue;

}

table

{

background-color: lightyellow;

border-collapse: collapse;

border: 1px solid gray;

}

td

{

padding: 5px;

}

tr:nth-child(odd)

{

background-color: white;

}

</style>

</head>

<body>

<?php

$MYURL = isset($_POST["MYURL" ]) ? $_POST["MYURL" ] : "";

$UrlDescription = isset($_POST["UrlDescription" ]) ? $_POST["UrlDescription" ] : "";

$iserr = false;

$formerr = array( "URLerror" => false, "UrlDescriptionerror" => false);

$inputs = array( "MYURL" => "MYURL", "UrlDescription" => "UrlDescription" );

if ( isset( $_POST["submit"] ) )

{

if ( $MYURL == "" )

{

$formerr[ "URLerror" ] = true;

$iserr = true;

}

if ( $UrlDescription == "" )

{

$formerr[ "UrlDescriptionerror" ] = true;

$iserr = true;

}

$query = "INSERT INTO myurltable ".

"( MYURL, UrlDescription )".

"VALUES ( '$MYURL', '$UrlDescription')";

if( !( $mydb = mysql_connect( "localhost","iw3htp", "password" ) ) )

die( "<p>Couldn't connect to the mydb</P>");

if ( !mysql_select_db( "MYURLs", $mydb ) )

die( "<p>Couldn't open the URL DB</p>" );

if ( !( $resultant = mysql_query( $query, $mydb ) ) )

{

print( "<p>Couldn't run the query</P>" );

die(mysql_error() );

}

mysql_close( $mydb );

die();

}

print( "<h1>MYURL UrlDescription Form</h1>

<p>Fill all the fields & click Register.</p>" );

if ( $iserr )

{

print( "<p class = 'error'>Starred Fields has to properly filled.</p>" );

}

print(" <!-- post the form data to the mytable.php -->

<form method = 'post' action = 'mytable.php'>

<h2> Informtion Needed</h2>" );

foreach ( $inputs as $inputnam => $inputsalt)

{

print( "<div><label>$inputsalt:</label><input type = 'text'

name = '$inputnam' value = '". $$inputnam. "'>" );

if ( $formerr[ ( $inputnam ). "error" ] == true )

print( "<span class = 'error'>*</span>" );

print( "</div>" );

}

print("<p class = 'head'><input type = 'submit' name = 'submit'

value = 'Resigtration'></p></form></body></html> ");

?>

</body>

</html>