﻿Public Class Form1

    '''' Variable declaration for counters and accumulator
    Dim rand_number As Integer = Int((10 * Rnd()) + 1)
    Dim chance As Integer = 5
    Dim guess_count As Integer = 0
    Dim total_count As Integer = 0

    Private Sub Check_button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Checkbutton.Click

        '''' Check if user inputs a number if not then ask for a number
        If TextBox1.Text = "" Then
            '''' msg Box asking user to enter number
            MsgBox("Enter a number to play the game :)", MsgBoxStyle.Critical)

        Else

            '''' This section works only if user inputs number
            '''' Input variable converting user text to integer
            Dim input As Integer = Integer.Parse(TextBox1.Text)

            If chance <> 1 Then
                If input <> rand_number Then

                    ''''Decreasing user chances every wrong guess
                    chance = chance - 1
                    '''' message to display if wrong guess
                    msglabel.Text = "Wrong Guess :( " + chance.ToString + " tries left!"
                    msglabel.ForeColor = Color.Red
                    msglabel2.Text = ""

                    ''''check if input if correct
                ElseIf input = rand_number Then
                    '''' increasing correct guess counter
                    guess_count = guess_count + 1

                    '''' increasing total guess count (accumulator)
                    total_count = total_count + 1

                    '''' resetting user chance for next round of game
                    chance = 5

                    '''' generate new random number between 1-10
                    rand_number = Int((10 * Rnd()) + 1)

                    '''' display message for correct guess
                    msglabel.Text = "Correct Guess! :)"
                    msglabel.ForeColor = Color.Green

                    '''' message displaying new round beginning
                    msglabel2.Text = "Another Number Generated" + vbNewLine + "Continue Guessing or Exit to quit!"
                End If

                '''' if user chances reduce to 0
            ElseIf chance = 1 Then

                '''' increase total game accumulator and reset chances and new random number
                total_count = total_count + 1
                MsgBox("Lost this round", MsgBoxStyle.Exclamation)
                chance = 5
                msg_label2.Text = "Another Number Generated" + vbNewLine + "Continue Guessing or Exit to quit!"
                rand_number = Int((10 * Rnd()) + 1)

            End If
        End If

        '''' To display the current correct guess count and total game count
        totalcountlabel.Text = total_count.ToString
        Guesscountlabel.Text = guess_count.ToString

        '''' textbox is selected and reset on clicking check button
        TextBox1.Select()
        TextBox1.Text = ""
    End Sub

    Private Sub exit_button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles exitbutton.Click


        ''''variable to store percentage of correct guess
        Dim percentage As Integer

        '''' to avoid divided by zero condition
        If total_count = 0 Then
            total_count = 1
        End If

        percentage = (guess_count / total_count) * 100

        '''' Message showing percentage of correct guess before closing application
        MsgBox("You guessed " + percentage.ToString + "% of correct numbers!", MsgBoxStyle.Information)

        '''' Closing application
        Application.Exit()
    End Sub
End Class