﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Checkbutton = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.exitbutton = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.msg_label = New System.Windows.Forms.Label()
        Me.msg_label2 = New System.Windows.Forms.Label()
        Me.msglabel = New System.Windows.Forms.Label()
        Me.msglabel2 = New System.Windows.Forms.Label()
        Me.Guesscountlabel = New System.Windows.Forms.Label()
        Me.totalcountlabel = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Checkbutton
        '
        Me.Checkbutton.Location = New System.Drawing.Point(12, 144)
        Me.Checkbutton.Name = "Checkbutton"
        Me.Checkbutton.Size = New System.Drawing.Size(97, 23)
        Me.Checkbutton.TabIndex = 0
        Me.Checkbutton.Text = "Check My Guess"
        Me.Checkbutton.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(133, 144)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(102, 23)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Start a New Game"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'exitbutton
        '
        Me.exitbutton.Location = New System.Drawing.Point(247, 144)
        Me.exitbutton.Name = "exitbutton"
        Me.exitbutton.Size = New System.Drawing.Size(98, 23)
        Me.exitbutton.TabIndex = 2
        Me.exitbutton.Text = "Exit"
        Me.exitbutton.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(168, 82)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(67, 20)
        Me.TextBox1.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(72, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(227, 49)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "I'm thinking of a number between 1 and 10. Enter your guess and click on the Chec" &
    "k My Guess button. "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(99, 85)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Your guess:"
        '
        'msg_label
        '
        Me.msg_label.AutoSize = True
        Me.msg_label.Location = New System.Drawing.Point(146, 58)
        Me.msg_label.Name = "msg_label"
        Me.msg_label.Size = New System.Drawing.Size(0, 13)
        Me.msg_label.TabIndex = 6
        '
        'msg_label2
        '
        Me.msg_label2.AutoSize = True
        Me.msg_label2.Location = New System.Drawing.Point(130, 58)
        Me.msg_label2.Name = "msg_label2"
        Me.msg_label2.Size = New System.Drawing.Size(0, 13)
        Me.msg_label2.TabIndex = 7
        '
        'msglabel
        '
        Me.msglabel.AutoSize = True
        Me.msglabel.Location = New System.Drawing.Point(149, 57)
        Me.msglabel.Name = "msglabel"
        Me.msglabel.Size = New System.Drawing.Size(16, 13)
        Me.msglabel.TabIndex = 8
        Me.msglabel.Text = "   "
        '
        'msglabel2
        '
        Me.msglabel2.AutoSize = True
        Me.msglabel2.Location = New System.Drawing.Point(136, 57)
        Me.msglabel2.Name = "msglabel2"
        Me.msglabel2.Size = New System.Drawing.Size(22, 13)
        Me.msglabel2.TabIndex = 9
        Me.msglabel2.Text = "     "
        '
        'Guesscountlabel
        '
        Me.Guesscountlabel.AutoSize = True
        Me.Guesscountlabel.Location = New System.Drawing.Point(259, 62)
        Me.Guesscountlabel.Name = "Guesscountlabel"
        Me.Guesscountlabel.Size = New System.Drawing.Size(39, 13)
        Me.Guesscountlabel.TabIndex = 10
        Me.Guesscountlabel.Text = "Label3"
        '
        'totalcountlabel
        '
        Me.totalcountlabel.AutoSize = True
        Me.totalcountlabel.Location = New System.Drawing.Point(262, 88)
        Me.totalcountlabel.Name = "totalcountlabel"
        Me.totalcountlabel.Size = New System.Drawing.Size(39, 13)
        Me.totalcountlabel.TabIndex = 11
        Me.totalcountlabel.Text = "Label3"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(366, 179)
        Me.Controls.Add(Me.totalcountlabel)
        Me.Controls.Add(Me.Guesscountlabel)
        Me.Controls.Add(Me.msglabel2)
        Me.Controls.Add(Me.msglabel)
        Me.Controls.Add(Me.msg_label2)
        Me.Controls.Add(Me.msg_label)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.exitbutton)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Checkbutton)
        Me.Name = "Form1"
        Me.Text = "Guess My Number"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Checkbutton As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents exitbutton As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents msg_label As Label
    Friend WithEvents msg_label2 As Label
    Friend WithEvents msglabel As Label
    Friend WithEvents msglabel2 As Label
    Friend WithEvents Guesscountlabel As Label
    Friend WithEvents totalcountlabel As Label
End Class
