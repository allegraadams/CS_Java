﻿Public Class frmMain
    Public Shared DtTable As New DataTable
    Private Shared SelectedQuest As Integer
    Private Shared TotalScore As Integer
    Private Shared DtSelected As New DataTable
    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        BuildDataTable()
        LoadComponent()
        rbOptionA.Checked = True
    End Sub
    Private Sub btnPrev_Click(sender As Object, e As EventArgs) Handles btnPrev.Click
        Dim dataView As DataView = DtTable.DefaultView
        dataView.RowFilter = "Id = '" & SelectedQuest & "'"
        Dim correctAnswer As String = "A"
        If rbOptionA.Checked Then
            correctAnswer = "A"
        ElseIf rbOptionB.Checked Then
            correctAnswer = "B"
        ElseIf rbOptionC.Checked Then
            correctAnswer = "C"
        ElseIf rbOptionB.Checked Then
            correctAnswer = "D"
        End If
        SelectedData(dataView, correctAnswer)
        ChooseData(SelectedQuest - 1)
    End Sub
    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        Dim dataView As DataView = DtTable.DefaultView
        dataView.RowFilter = "Id = '" & SelectedQuest & "'"
        Dim correctAnswer As String = "A"
        If rbOptionA.Checked Then
            correctAnswer = "A"
        ElseIf rbOptionB.Checked Then
            correctAnswer = "B"
        ElseIf rbOptionC.Checked Then
            correctAnswer = "C"
        ElseIf rbOptionB.Checked Then
            correctAnswer = "D"
        End If
        SelectedData(dataView, correctAnswer)
        ChooseData(SelectedQuest + 1)
    End Sub
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        For Each row As DataRow In DtSelected.Rows
            Dim dataView As DataView = DtTable.DefaultView
            dataView.RowFilter = "Id = '" & row.Item("Id") & "'"
            If dataView(0)(6).ToString() = row.Item("CorrectAnswer") Then
                TotalScore += TotalScore
            End If
        Next row
        lblMsg.Text = "Your total score is " & TotalScore & ""
    End Sub
    Private Sub btnChange_Click(sender As Object, e As EventArgs) Handles btnChange.Click
        For Each row As DataRow In DtSelected.Rows
            If row.Item("Id") = SelectedQuest Then
                If rbOptionA.Checked Then
                    row.Item("CorrectAnswer") = "A"
                ElseIf rbOptionB.Checked Then
                    row.Item("CorrectAnswer") = "B"
                ElseIf rbOptionC.Checked Then
                    row.Item("CorrectAnswer") = "C"
                ElseIf rbOptionB.Checked Then
                    row.Item("CorrectAnswer") = "D"
                End If
            End If
        Next row
    End Sub
    Private Sub btnIncorrect_Click(sender As Object, e As EventArgs) Handles btnIncorrect.Click
        For Each row As DataRow In DtSelected.Rows
            Dim dataView As DataView = DtTable.DefaultView
            dataView.RowFilter = "Id = '" & row.Item("Id") & "'"
            If dataView(0)(6).ToString() <> row.Item("CorrectAnswer") Then
                TotalScore += TotalScore
            End If
        Next row
        lblMsg.Text = "Your total in-correct answers are " & TotalScore & ""
    End Sub
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
    Sub BuildDataTable()
        Dim column1 As DataColumn = New DataColumn("Id")
        column1.DataType = System.Type.GetType("System.Int32")
        Dim column2 As DataColumn = New DataColumn("Question")
        column1.DataType = System.Type.GetType("System.String")
        Dim column3 As DataColumn = New DataColumn("AnswerA")
        column2.DataType = System.Type.GetType("System.String")
        Dim column4 As DataColumn = New DataColumn("AnswerB")
        column3.DataType = System.Type.GetType("System.String")
        Dim column5 As DataColumn = New DataColumn("AnswerC")
        column2.DataType = System.Type.GetType("System.String")
        Dim column6 As DataColumn = New DataColumn("AnswerD")
        column3.DataType = System.Type.GetType("System.String")
        Dim column7 As DataColumn = New DataColumn("CorrectAnswer")
        column3.DataType = System.Type.GetType("System.String")
        DtTable.Columns.Add(column1)
        DtTable.Columns.Add(column2)
        DtTable.Columns.Add(column3)
        DtTable.Columns.Add(column4)
        DtTable.Columns.Add(column5)
        DtTable.Columns.Add(column6)
        DtTable.Columns.Add(column7)
        Dim dtCol1 As DataColumn = New DataColumn("Id")
        dtCol1.DataType = System.Type.GetType("System.Int32")
        Dim dtCol2 As DataColumn = New DataColumn("Question")
        dtCol2.DataType = System.Type.GetType("System.String")
        Dim dtCol3 As DataColumn = New DataColumn("AnswerA")
        dtCol3.DataType = System.Type.GetType("System.String")
        Dim dtCol4 As DataColumn = New DataColumn("AnswerB")
        dtCol4.DataType = System.Type.GetType("System.String")
        Dim dtCol5 As DataColumn = New DataColumn("AnswerC")
        dtCol5.DataType = System.Type.GetType("System.String")
        Dim dtCol6 As DataColumn = New DataColumn("AnswerD")
        dtCol6.DataType = System.Type.GetType("System.String")
        Dim dtCol7 As DataColumn = New DataColumn("CorrectAnswer")
        dtCol7.DataType = System.Type.GetType("System.String")

        DtSelected.Columns.Add(dtCol1)
        DtSelected.Columns.Add(dtCol2)
        DtSelected.Columns.Add(dtCol3)
        DtSelected.Columns.Add(dtCol4)
        DtSelected.Columns.Add(dtCol5)
        DtSelected.Columns.Add(dtCol6)
        DtSelected.Columns.Add(dtCol7)
        Dim row As DataRow
        row = DtTable.NewRow()
        row.Item("Id") = 1
        row.Item("Question") = "Question 1"
        row.Item("AnswerA") = "Answer One"
        row.Item("AnswerB") = "Answer Two"
        row.Item("AnswerC") = "Answer Three"
        row.Item("AnswerD") = "Answer Four"
        row.Item("CorrectAnswer") = "A"
        DtTable.Rows.Add(row)
        row = DtTable.NewRow()
        row.Item("Id") = 2
        row.Item("Question") = "Question 2"
        row.Item("AnswerA") = "Answer One"
        row.Item("AnswerB") = "Answer Two"
        row.Item("AnswerC") = "Answer Three"
        row.Item("AnswerD") = "Answer Four"
        row.Item("CorrectAnswer") = "B"
        DtTable.Rows.Add(row)
    End Sub
    Sub LoadComponent()
        Dim dataView As DataView = DtTable.DefaultView
        dataView.RowFilter = "Id = '" & 1 & "'"
        SelectedQuest = CInt(Int(dataView(0)(0).ToString()))
        lblQuest.Text = dataView(0)(1).ToString()
        lblOpt1.Text = dataView(0)(2).ToString()
        lblOpt2.Text = dataView(0)(3).ToString()
        lblOpt3.Text = dataView(0)(4).ToString()
        lblOpt4.Text = dataView(0)(5).ToString()
        SelectedQuest = 1
    End Sub
    Sub SelectedData(dv As DataView, answer As String)
        Dim dataView As DataView = New DataView
        If DtSelected.Rows.Count > 0 Then
            dataView = DtSelected.DefaultView
            dataView.RowFilter = "Id = '" & CInt(Int(dv(0)(0).ToString())) & "'"
        End If
        If dataView.Count = 0 Then
            Dim row As DataRow
            row = DtSelected.NewRow()
            row.Item("Id") = CInt(Int(dv(0)(0).ToString()))
            row.Item("Question") = dv(0)(1).ToString()
            row.Item("AnswerA") = dv(0)(2).ToString()
            row.Item("AnswerB") = dv(0)(3).ToString()
            row.Item("AnswerC") = dv(0)(4).ToString()
            row.Item("AnswerD") = dv(0)(5).ToString()
            row.Item("CorrectAnswer") = answer
            DtSelected.Rows.Add(row)
        End If
    End Sub
    Sub ChooseData(Id As Integer)
        Dim dataView As DataView = New DataView
        If Id > 2 Then
            lblMsg.Text = "You reached max questions available"
        ElseIf Id < 1 Then
            lblMsg.Text = "You already reached 1st question"
        Else
            If DtSelected.Rows.Count > 0 Then
                dataView = DtSelected.DefaultView
                dataView.RowFilter = "Id = '" & Id & "'"
            End If
            If dataView.Count > 0 Then
                If dataView(0)(6).ToString() = "A" Then
                    rbOptionA.Checked = True
                ElseIf dataView(0)(6).ToString() = "B" Then
                    rbOptionB.Checked = True
                ElseIf dataView(0)(6).ToString() = "C" Then
                    rbOptionC.Checked = True
                ElseIf dataView(0)(6).ToString() = "D" Then
                    rbOptionD.Checked = True
                End If
            Else
                dataView = DtTable.DefaultView
                dataView.RowFilter = "Id = '" & Id & "'"
                rbOptionA.Checked = True
            End If
            SelectedQuest = CInt(Int(dataView(0)(0).ToString()))
            lblQuest.Text = dataView(0)(1).ToString()
            lblOpt1.Text = dataView(0)(2).ToString()
            lblOpt2.Text = dataView(0)(3).ToString()
            lblOpt3.Text = dataView(0)(4).ToString()
            lblOpt4.Text = dataView(0)(5).ToString()
            SelectedQuest = Id
        End If
    End Sub
End Class
