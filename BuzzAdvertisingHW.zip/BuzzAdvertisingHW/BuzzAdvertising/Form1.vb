﻿

Public Class Form1

    Private
        Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If RadioButton1.Checked = False Then
            RadioButton8.Enabled = False
        Else
            RadioButton8.Enabled = True
        End If

    End Sub
    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        RadioButton8.Enabled = True
        RadioButton7.Enabled = True
        RadioButton6.Enabled = True
        RadioButton5.Enabled = True

    End Sub
    Private Sub RadioButton4_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton4.CheckedChanged
        RadioButton8.Enabled = False
        RadioButton6.Enabled = False
        RadioButton7.Enabled = False
    End Sub
    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        RadioButton8.Enabled = False
        RadioButton7.Enabled = True
        RadioButton6.Enabled = True
        RadioButton5.Enabled = True
    End Sub
    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged
        RadioButton8.Enabled = False
        RadioButton7.Enabled = True
        RadioButton6.Enabled = True
        RadioButton5.Enabled = True
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim sz As Integer
        Dim loc As Integer
        If (TextBox1.Text = "") Then
            MessageBox.Show("Please Enter Company Name")
        ElseIf (TextBox2.Text = "") Then
            MessageBox.Show("Please Enter TelePhone Number")
        ElseIf (TextBox3.Text = "") Then
            MessageBox.Show("Please Enter Run Date")
        Else
            If RadioButton1.Checked = True Then
                sz = 1
            ElseIf RadioButton2.Checked = True Then
                sz = 2
            ElseIf RadioButton3.Checked = True Then
                sz = 3
            ElseIf RadioButton4.Checked = True Then
                sz = 4
            End If
            If RadioButton8.Checked = True Then
                loc = 1
            ElseIf RadioButton7.Checked = True Then
                loc = 2
            ElseIf RadioButton6.Checked = True Then
                loc = 3
            Else
                loc = 4
            End If
            Dim Ad1 As Ad = New Ad(TextBox1.Text, Convert.ToInt64(TextBox2.Text), sz, loc, TextBox3.Text)
            TextBox4.Text = Ad1.final_price
        End If

    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub
End Class

Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If RadioButton1.Checked = False Then
            RadioButton8.Enabled = False
        Else
            RadioButton8.Enabled = True
        End If

    End Sub
    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        RadioButton8.Enabled = True
        RadioButton7.Enabled = True
        RadioButton6.Enabled = True
        RadioButton5.Enabled = True

    End Sub
    Private Sub RadioButton4_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton4.CheckedChanged
        RadioButton8.Enabled = False
        RadioButton6.Enabled = False
        RadioButton7.Enabled = False
    End Sub
    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        RadioButton8.Enabled = False
        RadioButton7.Enabled = True
        RadioButton6.Enabled = True
        RadioButton5.Enabled = True
    End Sub
    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged
        RadioButton8.Enabled = False
        RadioButton7.Enabled = True
        RadioButton6.Enabled = True
        RadioButton5.Enabled = True
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim sz As Integer
        Dim loc As Integer
        If (TextBox1.Text = "") Then
            MessageBox.Show("Please Enter Company Name")
        ElseIf (TextBox2.Text = "") Then
            MessageBox.Show("Please Enter TelePhone Number")
        ElseIf (TextBox3.Text = "") Then
            MessageBox.Show("Please Enter Run Date")
        Else
            If RadioButton1.Checked = True Then
                sz = 1
            ElseIf RadioButton2.Checked = True Then
                sz = 2
            ElseIf RadioButton3.Checked = True Then
                sz = 3
            ElseIf RadioButton4.Checked = True Then
                sz = 4
            End If
            If RadioButton8.Checked = True Then
                loc = 1
            ElseIf RadioButton7.Checked = True Then
                loc = 2
            ElseIf RadioButton6.Checked = True Then
                loc = 3
            Else
                loc = 4
            End If
            Dim Ad1 As Ad = New Ad(TextBox1.Text, Convert.ToInt64(TextBox2.Text), sz, loc, TextBox3.Text)
            TextBox4.Text = Ad1.final_price
        End If

    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub
End Class
Public Class Ad
    Private compname As String
    Private telephone As Long
    Private price As Double
    Private size As Double
    Private location As Double
    Private rundate As String
    Public Sub New(ByVal Cname As String, ByVal tele As Long, ByVal sz As Integer, ByVal loc As Integer, rundt As String)
        compname = Cname
        telephone = tele
        rundate = rundt
        If (sz = 1) Then
            size = 225
        ElseIf (sz = 2) Then
            size = 225 * 0.65
        ElseIf (sz = 3) Then
            size = 225 * 0.4
        Else
            size = 35
        End If
        If (loc = 1) Then
            location = 1
        ElseIf (loc = 2) Then
            location = 1.2
        ElseIf (loc = 3) Then
            location = 1.15
        Else
            location = 1.4
        End If
        price = size * location
    End Sub
    Public ReadOnly Property final_price As Double
        Get
            Return price
        End Get
    End Property
End Class