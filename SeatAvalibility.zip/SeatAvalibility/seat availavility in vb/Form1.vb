﻿Public Class Form1
    Private availableSeats(7) As Boolean
    Private buttons(7) As RadioButton
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For i As Integer = 0 To 7
            buttons(i) = New RadioButton
        Next
        buttons(0) = seat10ARadioButton
        buttons(1) = seat10BRadioButton
        buttons(2) = seat11ARadioButton
        buttons(3) = seat11BRadioButton
        buttons(4) = seat12ARadioButton
        buttons(5) = seat12BRadioButton
        buttons(6) = seat13ARadioButton
        buttons(7) = seat13BRadioButton
        For j As Integer = 0 To 7
            buttons(j).Checked = False
            availableSeats(j) = True
        Next
    End Sub

    Private Sub UpdateSeatButtons()
        For i As Integer = 0 To 7
            If availableSeats(i).Equals(False) Then
                buttons(i).Enabled = False
            End If
        Next
    End Sub
    Private Function CheckForAvailable() As Boolean
        Dim status As Boolean
        For i As Integer = 0 To 7
            If availableSeats(i).Equals(True) Then
                status = True
            Else
                status = False
            End If
        Next
        Return status
    End Function

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnConfirmSeat_Click(sender As Object, e As EventArgs) Handles btnConfirmSeat.Click
        For i As Integer = 0 To 7
            If buttons(i).Checked Then
                availableSeats(i) = False
                UpdateSeatButtons()
            End If
        Next
        If CheckForAvailable() Then
            MessageBox.Show(txtName.Text + " your Seat is Confirmed")
        Else
            MessageBox.Show("Flight is full")

        End If
    End Sub
End Class
