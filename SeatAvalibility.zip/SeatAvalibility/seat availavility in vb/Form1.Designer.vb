﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.seat13BRadioButton = New System.Windows.Forms.RadioButton()
        Me.seat13ARadioButton = New System.Windows.Forms.RadioButton()
        Me.seat12BRadioButton = New System.Windows.Forms.RadioButton()
        Me.seat12ARadioButton = New System.Windows.Forms.RadioButton()
        Me.seat11BRadioButton = New System.Windows.Forms.RadioButton()
        Me.seat11ARadioButton = New System.Windows.Forms.RadioButton()
        Me.seat10BRadioButton = New System.Windows.Forms.RadioButton()
        Me.seat10ARadioButton = New System.Windows.Forms.RadioButton()
        Me.btnConfirmSeat = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.seat_availavility_in_vb.My.Resources.Resources.dolphin
        Me.PictureBox1.Location = New System.Drawing.Point(41, 77)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(161, 53)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(63, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(119, 18)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Island Breezes"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(63, 47)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(93, 18)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Sea Planes"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(52, 149)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(100, 20)
        Me.txtName.TabIndex = 3
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.seat13BRadioButton)
        Me.GroupBox1.Controls.Add(Me.seat13ARadioButton)
        Me.GroupBox1.Controls.Add(Me.seat12BRadioButton)
        Me.GroupBox1.Controls.Add(Me.seat12ARadioButton)
        Me.GroupBox1.Controls.Add(Me.seat11BRadioButton)
        Me.GroupBox1.Controls.Add(Me.seat11ARadioButton)
        Me.GroupBox1.Controls.Add(Me.seat10BRadioButton)
        Me.GroupBox1.Controls.Add(Me.seat10ARadioButton)
        Me.GroupBox1.Location = New System.Drawing.Point(52, 188)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(200, 172)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Seat Selection"
        '
        'seat13BRadioButton
        '
        Me.seat13BRadioButton.AutoSize = True
        Me.seat13BRadioButton.Location = New System.Drawing.Point(111, 137)
        Me.seat13BRadioButton.Name = "seat13BRadioButton"
        Me.seat13BRadioButton.Size = New System.Drawing.Size(44, 17)
        Me.seat13BRadioButton.TabIndex = 7
        Me.seat13BRadioButton.TabStop = True
        Me.seat13BRadioButton.Text = "13B"
        Me.seat13BRadioButton.UseVisualStyleBackColor = True
        '
        'seat13ARadioButton
        '
        Me.seat13ARadioButton.AutoSize = True
        Me.seat13ARadioButton.Location = New System.Drawing.Point(14, 137)
        Me.seat13ARadioButton.Name = "seat13ARadioButton"
        Me.seat13ARadioButton.Size = New System.Drawing.Size(44, 17)
        Me.seat13ARadioButton.TabIndex = 6
        Me.seat13ARadioButton.TabStop = True
        Me.seat13ARadioButton.Text = "13A"
        Me.seat13ARadioButton.UseVisualStyleBackColor = True
        '
        'seat12BRadioButton
        '
        Me.seat12BRadioButton.AutoSize = True
        Me.seat12BRadioButton.Location = New System.Drawing.Point(111, 101)
        Me.seat12BRadioButton.Name = "seat12BRadioButton"
        Me.seat12BRadioButton.Size = New System.Drawing.Size(44, 17)
        Me.seat12BRadioButton.TabIndex = 5
        Me.seat12BRadioButton.TabStop = True
        Me.seat12BRadioButton.Text = "12B"
        Me.seat12BRadioButton.UseVisualStyleBackColor = True
        '
        'seat12ARadioButton
        '
        Me.seat12ARadioButton.AutoSize = True
        Me.seat12ARadioButton.Location = New System.Drawing.Point(14, 101)
        Me.seat12ARadioButton.Name = "seat12ARadioButton"
        Me.seat12ARadioButton.Size = New System.Drawing.Size(44, 17)
        Me.seat12ARadioButton.TabIndex = 4
        Me.seat12ARadioButton.TabStop = True
        Me.seat12ARadioButton.Text = "12A"
        Me.seat12ARadioButton.UseVisualStyleBackColor = True
        '
        'seat11BRadioButton
        '
        Me.seat11BRadioButton.AutoSize = True
        Me.seat11BRadioButton.Location = New System.Drawing.Point(111, 69)
        Me.seat11BRadioButton.Name = "seat11BRadioButton"
        Me.seat11BRadioButton.Size = New System.Drawing.Size(44, 17)
        Me.seat11BRadioButton.TabIndex = 3
        Me.seat11BRadioButton.TabStop = True
        Me.seat11BRadioButton.Text = "11B"
        Me.seat11BRadioButton.UseVisualStyleBackColor = True
        '
        'seat11ARadioButton
        '
        Me.seat11ARadioButton.AutoSize = True
        Me.seat11ARadioButton.Location = New System.Drawing.Point(14, 69)
        Me.seat11ARadioButton.Name = "seat11ARadioButton"
        Me.seat11ARadioButton.Size = New System.Drawing.Size(44, 17)
        Me.seat11ARadioButton.TabIndex = 2
        Me.seat11ARadioButton.TabStop = True
        Me.seat11ARadioButton.Text = "11A"
        Me.seat11ARadioButton.UseVisualStyleBackColor = True
        '
        'seat10BRadioButton
        '
        Me.seat10BRadioButton.AutoSize = True
        Me.seat10BRadioButton.Location = New System.Drawing.Point(111, 34)
        Me.seat10BRadioButton.Name = "seat10BRadioButton"
        Me.seat10BRadioButton.Size = New System.Drawing.Size(44, 17)
        Me.seat10BRadioButton.TabIndex = 1
        Me.seat10BRadioButton.TabStop = True
        Me.seat10BRadioButton.Text = "10B"
        Me.seat10BRadioButton.UseVisualStyleBackColor = True
        '
        'seat10ARadioButton
        '
        Me.seat10ARadioButton.AutoSize = True
        Me.seat10ARadioButton.Location = New System.Drawing.Point(14, 34)
        Me.seat10ARadioButton.Name = "seat10ARadioButton"
        Me.seat10ARadioButton.Size = New System.Drawing.Size(44, 17)
        Me.seat10ARadioButton.TabIndex = 0
        Me.seat10ARadioButton.TabStop = True
        Me.seat10ARadioButton.Text = "10A"
        Me.seat10ARadioButton.UseVisualStyleBackColor = True
        '
        'btnConfirmSeat
        '
        Me.btnConfirmSeat.Location = New System.Drawing.Point(52, 366)
        Me.btnConfirmSeat.Name = "btnConfirmSeat"
        Me.btnConfirmSeat.Size = New System.Drawing.Size(75, 40)
        Me.btnConfirmSeat.TabIndex = 8
        Me.btnConfirmSeat.Text = "Confirm Seat"
        Me.btnConfirmSeat.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(151, 366)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 40)
        Me.btnExit.TabIndex = 8
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(49, 133)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(88, 13)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Passenger Name"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(260, 418)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnConfirmSeat)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "Form1"
        Me.Text = "Seat Selection"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents seat13BRadioButton As RadioButton
    Friend WithEvents seat13ARadioButton As RadioButton
    Friend WithEvents seat12BRadioButton As RadioButton
    Friend WithEvents seat12ARadioButton As RadioButton
    Friend WithEvents seat11BRadioButton As RadioButton
    Friend WithEvents seat11ARadioButton As RadioButton
    Friend WithEvents seat10BRadioButton As RadioButton
    Friend WithEvents seat10ARadioButton As RadioButton
    Friend WithEvents btnConfirmSeat As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents Label3 As Label
End Class
