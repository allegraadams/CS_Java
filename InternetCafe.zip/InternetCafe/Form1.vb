﻿Public Class MainForm
    Const HOURLY_RATE = 12.0
    Private Sub calculateButton_Click(sender As Object, e As EventArgs) Handles calculateButton.Click
        Dim hours As Double
        Dim amount As Double
        Dim isConverted As Boolean
        isConverted = Double.TryParse(hoursTextBox.Text, hours)
        If isConverted Then
            amount = hours * HOURLY_RATE
        End If
        amountDueLabel.Text = Format(amount, "Currency")
    End Sub
    Private Sub clearButton_Click(sender As Object, e As EventArgs) Handles clearButton.Click
        lastNameTextBox.Text = ""
        firstNameTextBox.Text = ""
        hoursTextBox.Text = ""
        amountDueLabel.Text = ""
    End Sub
    Private Sub exitButton_Click(sender As Object, e As EventArgs) Handles exitButton.Click
        Me.Close()
    End Sub
End Class