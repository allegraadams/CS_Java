﻿
Public Class MainForm

    ' Calculate buttong click event handler
    Private Sub btnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click
        ' Variables declaration
        Dim totalPrice As Double
        Dim noTees As Integer
        ' Number of tees reading from text box
        noTees = Convert.ToInt32(tbNumberOrdered.Text)
        ' Set total price to 0
        totalPrice = 0
        ' If Men radio button is checked
        If rbMen.Checked Then
            ' If S is selected
            If rbS.Checked Then
                ' Adding tee shirt price
                totalPrice = 17.75
            ElseIf rbL.Checked Or rbM.Checked Then
                ' Adding tee shirt price
                totalPrice = 19.75
            End If

            ' If picture is selected
            If cbPicture.Checked Then
                ' If S or M is selected
                If rbS.Checked Or rbM.Checked Then
                    ' Adding tee shirt price
                    totalPrice = totalPrice + 5
                ElseIf rbL.Checked Then
                    ' Adding tee shirt price
                    totalPrice = totalPrice + 6
                End If
            End If
            ' IF name is selected
            If cbName.Checked Then
                totalPrice = totalPrice + 7.5
            End If
            ' Multiplying with number of tees
            totalPrice = totalPrice * noTees
            ' Adding sales tax
            totalPrice = totalPrice + (totalPrice * 0.02)
            ' If Women radio button is checked
        Else
            ' Adding tee shirt price
            totalPrice = 17.75
            ' If picture is selected
            If cbPicture.Checked Then
                totalPrice = totalPrice + 5
            End If
            ' IF name is selected
            If cbName.Checked Then
                totalPrice = totalPrice + 7.5
            End If
            ' Multiplying with number of tees
            totalPrice = totalPrice * noTees
            ' Adding sales tax
            totalPrice = totalPrice + (totalPrice * 0.02)
        End If
        ' Writing result to text box
        tbTotalPrice.Text = "$" + totalPrice.ToString("#.##")
    End Sub
    ' Exit button click event handler
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        ' Exit button click event
        Application.Exit()
    End Sub
End Class