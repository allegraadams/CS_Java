﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.rbMen = New System.Windows.Forms.RadioButton()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.rbWomen = New System.Windows.Forms.RadioButton()
        Me.rbS = New System.Windows.Forms.RadioButton()
        Me.rbM = New System.Windows.Forms.RadioButton()
        Me.rbL = New System.Windows.Forms.RadioButton()
        Me.tbNumberOrdered = New System.Windows.Forms.TextBox()
        Me.tbTotalPrice = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblTotPrice = New System.Windows.Forms.Label()
        Me.cbPicture = New System.Windows.Forms.CheckBox()
        Me.cbName = New System.Windows.Forms.CheckBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'rbMen
        '
        Me.rbMen.AutoSize = True
        Me.rbMen.Location = New System.Drawing.Point(27, 37)
        Me.rbMen.Name = "rbMen"
        Me.rbMen.Size = New System.Drawing.Size(46, 17)
        Me.rbMen.TabIndex = 0
        Me.rbMen.TabStop = True
        Me.rbMen.Text = "Men"
        Me.rbMen.UseVisualStyleBackColor = True
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(413, 215)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 1
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(413, 259)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 2
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'rbWomen
        '
        Me.rbWomen.AutoSize = True
        Me.rbWomen.Location = New System.Drawing.Point(27, 78)
        Me.rbWomen.Name = "rbWomen"
        Me.rbWomen.Size = New System.Drawing.Size(62, 17)
        Me.rbWomen.TabIndex = 3
        Me.rbWomen.TabStop = True
        Me.rbWomen.Text = "Women"
        Me.rbWomen.UseVisualStyleBackColor = True
        '
        'rbS
        '
        Me.rbS.AutoSize = True
        Me.rbS.Location = New System.Drawing.Point(6, 24)
        Me.rbS.Name = "rbS"
        Me.rbS.Size = New System.Drawing.Size(32, 17)
        Me.rbS.TabIndex = 4
        Me.rbS.TabStop = True
        Me.rbS.Text = "S"
        Me.rbS.UseVisualStyleBackColor = True
        '
        'rbM
        '
        Me.rbM.AutoSize = True
        Me.rbM.Location = New System.Drawing.Point(6, 64)
        Me.rbM.Name = "rbM"
        Me.rbM.Size = New System.Drawing.Size(34, 17)
        Me.rbM.TabIndex = 5
        Me.rbM.TabStop = True
        Me.rbM.Text = "M"
        Me.rbM.UseVisualStyleBackColor = True
        '
        'rbL
        '
        Me.rbL.AutoSize = True
        Me.rbL.Location = New System.Drawing.Point(6, 107)
        Me.rbL.Name = "rbL"
        Me.rbL.Size = New System.Drawing.Size(31, 17)
        Me.rbL.TabIndex = 6
        Me.rbL.TabStop = True
        Me.rbL.Text = "L"
        Me.rbL.UseVisualStyleBackColor = True
        '
        'tbNumberOrdered
        '
        Me.tbNumberOrdered.Location = New System.Drawing.Point(296, 215)
        Me.tbNumberOrdered.Name = "tbNumberOrdered"
        Me.tbNumberOrdered.Size = New System.Drawing.Size(100, 20)
        Me.tbNumberOrdered.TabIndex = 7
        '
        'tbTotalPrice
        '
        Me.tbTotalPrice.BackColor = System.Drawing.SystemColors.Menu
        Me.tbTotalPrice.Location = New System.Drawing.Point(296, 259)
        Me.tbTotalPrice.Name = "tbTotalPrice"
        Me.tbTotalPrice.Size = New System.Drawing.Size(100, 20)
        Me.tbTotalPrice.TabIndex = 8
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(202, 220)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(88, 13)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Number Ordered:"
        '
        'lblTotPrice
        '
        Me.lblTotPrice.AutoSize = True
        Me.lblTotPrice.Location = New System.Drawing.Point(229, 262)
        Me.lblTotPrice.Name = "lblTotPrice"
        Me.lblTotPrice.Size = New System.Drawing.Size(61, 13)
        Me.lblTotPrice.TabIndex = 10
        Me.lblTotPrice.Text = "Total Price:"
        '
        'cbPicture
        '
        Me.cbPicture.AutoSize = True
        Me.cbPicture.Location = New System.Drawing.Point(370, 38)
        Me.cbPicture.Name = "cbPicture"
        Me.cbPicture.Size = New System.Drawing.Size(59, 17)
        Me.cbPicture.TabIndex = 11
        Me.cbPicture.Text = "Picture"
        Me.cbPicture.UseVisualStyleBackColor = True
        '
        'cbName
        '
        Me.cbName.AutoSize = True
        Me.cbName.Location = New System.Drawing.Point(370, 78)
        Me.cbName.Name = "cbName"
        Me.cbName.Size = New System.Drawing.Size(54, 17)
        Me.cbName.TabIndex = 12
        Me.cbName.Text = "Name"
        Me.cbName.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbS)
        Me.GroupBox1.Controls.Add(Me.rbM)
        Me.GroupBox1.Controls.Add(Me.rbL)
        Me.GroupBox1.Location = New System.Drawing.Point(180, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(110, 130)
        Me.GroupBox1.TabIndex = 13
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Size"
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.cbName)
        Me.Controls.Add(Me.cbPicture)
        Me.Controls.Add(Me.lblTotPrice)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.tbTotalPrice)
        Me.Controls.Add(Me.tbNumberOrdered)
        Me.Controls.Add(Me.rbWomen)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.rbMen)
        Me.Name = "MainForm"
        Me.Text = "Just Tees"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents rbMen As RadioButton
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents rbWomen As RadioButton
    Friend WithEvents rbS As RadioButton
    Friend WithEvents rbM As RadioButton
    Friend WithEvents rbL As RadioButton
    Friend WithEvents tbNumberOrdered As TextBox
    Friend WithEvents tbTotalPrice As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents lblTotPrice As Label
    Friend WithEvents cbPicture As CheckBox
    Friend WithEvents cbName As CheckBox
    Friend WithEvents GroupBox1 As GroupBox
End Class
