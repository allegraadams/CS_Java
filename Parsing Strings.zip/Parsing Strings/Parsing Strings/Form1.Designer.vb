﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rdspace = New System.Windows.Forms.RadioButton()
        Me.rdcrlf = New System.Windows.Forms.RadioButton()
        Me.rdcomma = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtItems = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.listbox = New System.Windows.Forms.ListBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rdspace)
        Me.GroupBox1.Controls.Add(Me.rdcrlf)
        Me.GroupBox1.Controls.Add(Me.rdcomma)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(145, 225)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Select a delimeter"
        '
        'rdspace
        '
        Me.rdspace.AutoSize = True
        Me.rdspace.Location = New System.Drawing.Point(17, 76)
        Me.rdspace.Name = "rdspace"
        Me.rdspace.Size = New System.Drawing.Size(56, 17)
        Me.rdspace.TabIndex = 2
        Me.rdspace.TabStop = True
        Me.rdspace.Text = "Space"
        Me.rdspace.UseVisualStyleBackColor = True
        '
        'rdcrlf
        '
        Me.rdcrlf.AutoSize = True
        Me.rdcrlf.Location = New System.Drawing.Point(17, 53)
        Me.rdcrlf.Name = "rdcrlf"
        Me.rdcrlf.Size = New System.Drawing.Size(55, 17)
        Me.rdcrlf.TabIndex = 1
        Me.rdcrlf.TabStop = True
        Me.rdcrlf.Text = "CR-LF"
        Me.rdcrlf.UseVisualStyleBackColor = True
        '
        'rdcomma
        '
        Me.rdcomma.AutoSize = True
        Me.rdcomma.Location = New System.Drawing.Point(17, 29)
        Me.rdcomma.Name = "rdcomma"
        Me.rdcomma.Size = New System.Drawing.Size(60, 17)
        Me.rdcomma.TabIndex = 0
        Me.rdcomma.TabStop = True
        Me.rdcomma.Text = "Comma"
        Me.rdcomma.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtItems)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.Button1)
        Me.GroupBox2.Location = New System.Drawing.Point(177, 21)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(373, 103)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Build a list from a text box"
        '
        'txtItems
        '
        Me.txtItems.Location = New System.Drawing.Point(25, 36)
        Me.txtItems.Multiline = True
        Me.txtItems.Name = "txtItems"
        Me.txtItems.Size = New System.Drawing.Size(226, 61)
        Me.txtItems.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(22, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(227, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Enter items, separated by the chosen delimeter"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(254, 62)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(97, 22)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "Parse text to list"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Controls.Add(Me.listbox)
        Me.GroupBox3.Controls.Add(Me.Button2)
        Me.GroupBox3.Location = New System.Drawing.Point(177, 130)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(373, 107)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Build a text box from a list"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(25, 20)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(199, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Use this list to build the text box contents"
        '
        'listbox
        '
        Me.listbox.FormattingEnabled = True
        Me.listbox.Location = New System.Drawing.Point(25, 33)
        Me.listbox.Name = "listbox"
        Me.listbox.Size = New System.Drawing.Size(226, 56)
        Me.listbox.TabIndex = 5
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(254, 66)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(97, 23)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "Build text from list"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(177, 243)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 3
        Me.Button3.Text = "Clear"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(475, 243)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 4
        Me.Button4.Text = "Exit"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(614, 298)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Parsing Strings"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents rdspace As RadioButton
    Friend WithEvents rdcrlf As RadioButton
    Friend WithEvents rdcomma As RadioButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents txtItems As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Label2 As Label
    Friend WithEvents listbox As ListBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
End Class
