﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        rdcomma.Checked = True
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click 'parse text to list button code
        'declare all the variables
        Dim delimiter, tempString, tempWord As String
        Dim oldIndex = 0, newIndex, lenght, advanceSize As Integer
        listbox.Enabled = True
        listbox.Items.Clear() 'clears the listbox
        'checking the which readio button is selected and set delemiter accordingly
        If rdcomma.Checked = True Then
            delimiter = ","
            advanceSize = 1
        ElseIf rdcrlf.Checked = True Then
            delimiter = vbCrLf
            advanceSize = 2
        ElseIf rdspace.Checked = True Then
            delimiter = " "
            advanceSize = 1
        Else
            Exit Sub
        End If
        tempString = txtItems.Text ''assing textbox value to tempstring
        lenght = txtItems.Text.Length() 'fing the length of the tempstring
        While (oldIndex < lenght)
            newIndex = tempString.IndexOfAny(delimiter) 'finds the index of the delemiter in the tempstring
            If (newIndex > -1) Then 'if index is not greater than -1 means delemiter no in the tempstring so exit the while loop
                oldIndex = 0 'make oldindex 0
                tempWord = tempString.Substring(oldIndex, newIndex) 'assign tempword
                oldIndex = newIndex + advanceSize
                tempString = tempString.Substring((newIndex + advanceSize), lenght - oldIndex)
                lenght = tempString.Length() 'add tempword to the listbox
                listbox.Items.Add(tempWord)
            Else
                Exit While
            End If
        End While
        listbox.Items.Add(tempString)
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click 'Build text from list button code
        'declare all the variables
        Dim delimiter, tempString As String
        Dim i, advanceSize As Integer
        txtItems.Clear()
        'checking the which readio button is selected and set delemiter accordingly
        If rdcomma.Checked = True Then
            delimiter = ","
            advanceSize = 1
        ElseIf rdcrlf.Checked = True Then
            delimiter = vbCrLf
            advanceSize = 2
        ElseIf rdspace.Checked = True Then
            delimiter = " "
            advanceSize = 1
        Else ' if non of the radio button is chcecked then exit the sub
            Exit Sub
        End If
        tempString = "" 'assign tempstring to empty
        For i = 0 To listbox.Items.Count - 1 'for loop untill no if items in the list box
            tempString += listbox.Items.Item(i) + delimiter 'add the item from the list box and delemiter to the tempstring
        Next
        txtItems.Text = tempString 'assign the resultant string to the textbox
    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click 'Exit button code
        Me.Close() 'close the form
    End Sub
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click 'clear button code
        txtItems.Clear() 'clear the text box
        listbox.Items.Clear() 'clear the list box
    End Sub
End Class